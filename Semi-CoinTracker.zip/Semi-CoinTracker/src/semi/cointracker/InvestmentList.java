/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semi.cointracker;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;


public class InvestmentList implements Serializable{
    
    private Investment Investment;
    private ArrayList<Investment> ListofInvestments = new ArrayList<>();
    private String InvestmentListFile = "InvestmentListFile";
    
    public ArrayList<Investment> getInvestmentList(){
        return ListofInvestments;
    }
    public void setListofInvestments(ArrayList<Investment> ListofInvestments){
        this.ListofInvestments = ListofInvestments;
    }
    public InvestmentList() throws IOException, FileNotFoundException, ClassNotFoundException{
    this.readKeyListFile();
    if(ListofInvestments.isEmpty() || ListofInvestments == null){
    this.createInvestmentList();
    this.readKeyListFile();
    this.writeKeyListFile();
    }
    }
    public void createInvestmentList(){
        for (int i=1;i<=1; i++){
            Investment = new Investment("Example", 0, 0);  
            ListofInvestments.add(Investment);   
        }
        
    }
    public void readKeyListFile() throws FileNotFoundException, IOException, ClassNotFoundException{
    FileInputStream file;
    ObjectInputStream object;
    try{
        file = new FileInputStream(InvestmentListFile);
        object = new ObjectInputStream(file);
        ListofInvestments = (ArrayList) object.readObject();
        object.close();
        //System.out.print(CryptoKeyList);
        if(!ListofInvestments.isEmpty()){
            System.out.print("");
        }
    }
    catch (IOException E){
        System.out.print("");
                
    }
  
}
public void writeKeyListFile() throws FileNotFoundException, IOException{
    FileOutputStream Fileout;
    ObjectOutputStream Objectout;
    try{
        Fileout = new FileOutputStream(InvestmentListFile);
        Objectout = new ObjectOutputStream(Fileout);
        Objectout.writeObject(ListofInvestments);
        Objectout.close();
    }
    catch(IOException E){
        System.out.print("this did not work ");
    }
} 
  //  public void PrintInvestmentList(){
        //for (Investment ListofInvestments : ListofInvestments){
           // System.out.println(ListofInvestments);
       // }
   // } 
}
