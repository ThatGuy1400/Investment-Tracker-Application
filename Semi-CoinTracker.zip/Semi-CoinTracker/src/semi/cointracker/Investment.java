/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semi.cointracker;

import java.io.Serializable;


public class Investment implements Serializable {
    private String name; 
    private double price;
    private double amount; 
    private double total;
    

public Investment(String name, double price, double amount){
    this.name = name; 
    this.price = price; 
    this.amount = amount;
}

public double Calculation(){
    name = getName();
    price = getPrice();
    amount = getAmount(); 
    total = price * amount;
    return total;
    } 
public String getName(){  
  return name ;
}
public void setName(String name){
    this.name = name;
}
public void setPrice(double price){
    this.price = price;
}    
public double getPrice(){
    return price;
}
public void setAmount(double amount){
    this.amount = amount;
}    
public double getAmount(){
    return amount;
}
@Override
    public String toString(){
        return "This is your blanace" + Calculation() + "/n" + "This is your updated coin, here are the details: " + "Name " + getName() + ":" + "Initial price " + getPrice() + ":" + "Amount Purchased " + getAmount()+ ":" ;      
    }
}