/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semi.cointracker;

import java.util.Comparator;

/**
 *
 * @author brand
 */
public class keyComparator implements Comparator<CryptoKey>{

    @Override
    public int compare(CryptoKey o1, CryptoKey o2) {
        return o1.getName().compareTo(o2.getName());
    }
    
}
