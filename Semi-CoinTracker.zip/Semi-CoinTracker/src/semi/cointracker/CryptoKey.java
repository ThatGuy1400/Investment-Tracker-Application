/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semi.cointracker;

import java.io.Serializable;

/**
 *
 * @author brand
 */
public class CryptoKey implements Serializable {
    private String name;
    private String key; 

    public CryptoKey link;
    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

public CryptoKey(String name, String key){
    this.name = name; 
    this.key = key;
}
public CryptoKey(){
    name = "";
    key = "";
}


}