/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semi.cointracker;
import static java.io.FileDescriptor.in;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author brand
 */
public class KeyList implements Serializable{
    private LinkedList<CryptoKey> List = new LinkedList<>();
    private ArrayList<CryptoKey> CryptoKeyList = new ArrayList<>();
    private CryptoKey cryptokey;
    private String KeyListFile = "ListofKeys.txt";
    private keyComparator KeyComparator; 
    
public KeyList() throws IOException, FileNotFoundException, ClassNotFoundException{
    printKeyList();
    this.readKeyListFile();
    if(CryptoKeyList.isEmpty() || CryptoKeyList == null){
    this.ListofKeys();
    this.readKeyListFile();
    this.writeKeyListFile();
}   
}
public String getFile(){
    return KeyListFile;
}

public ArrayList<CryptoKey> getKeyList(){
    return CryptoKeyList;
}    
public LinkedList<CryptoKey> getLinkedList(){
    return List;
}

    public void setKeyList(ArrayList<CryptoKey> KeyList) {
        this.CryptoKeyList = KeyList;
    }
public void ListofKeys(){
    cryptokey = new CryptoKey("Coin" , "Example");
    CryptoKeyList.add(cryptokey);
    
    CryptoKeyList.sort(new keyComparator());
    for(int i=CryptoKeyList.size()-1;i>=0;i--){
        List.add(CryptoKeyList.get(i));
}    
  
   
}
public void readKeyListFile() throws FileNotFoundException, IOException, ClassNotFoundException{
    FileInputStream file;
    ObjectInputStream object;
    try{
        file = new FileInputStream(KeyListFile);
        object = new ObjectInputStream(file);
        CryptoKeyList = (ArrayList) object.readObject();
        object.close();
        //System.out.print(CryptoKeyList);
        if(!CryptoKeyList.isEmpty()){
            System.out.print("");
        }
    }
    catch (IOException E){
        System.out.print("");
                
    }
  
}
public void writeKeyListFile() throws FileNotFoundException, IOException{
    FileOutputStream Fileout;
    ObjectOutputStream Objectout;
    try{
        Fileout = new FileOutputStream(KeyListFile);
        Objectout = new ObjectOutputStream(Fileout);
        Objectout.writeObject(CryptoKeyList);
        Objectout.close();
    }
    catch(IOException E){
        System.out.print("this did not work ");
    }
} 

 
public void addkey(CryptoKey cryptokey){
     ListIterator<CryptoKey> KeyIt = List.listIterator();
     while (KeyIt.hasNext()){
        // cryptokey = new CryptoKey();
         List.add(cryptokey);
         
     }
}
public void removekey(CryptoKey cryptokey){
    
}
public void printKeyList(){
    ListIterator<CryptoKey> KeyIt = List.listIterator();
    while (KeyIt.hasNext()){
        System.out.print(KeyIt.next());
        System.out.println("helo");
    }
}

}
