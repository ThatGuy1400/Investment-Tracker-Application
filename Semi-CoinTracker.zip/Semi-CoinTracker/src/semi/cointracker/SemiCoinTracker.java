/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semi.cointracker;

import MVC.controller.InvestmentController2;
import MVC.controller.controller;
import java.io.FileNotFoundException;
import java.io.IOException;



public class SemiCoinTracker {
   
    
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        //controller controller =new controller();
        InvestmentController2 con = new InvestmentController2();
     
        
}
}