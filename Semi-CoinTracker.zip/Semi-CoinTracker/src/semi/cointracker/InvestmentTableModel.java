/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semi.cointracker;

import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author brand
 */
public class InvestmentTableModel extends AbstractTableModel{
    private String[] columnNames = {"Name", "Price", "amount"};
    private ArrayList<Investment> investmentList;
  
    
    public InvestmentTableModel(ArrayList<Investment> newInstrumentList){

        investmentList = newInstrumentList;
}
    
    
   @Override
    public int getRowCount() {
        return investmentList.size();
        
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
     }

    @Override
    public Object getValueAt(int row, int col) {
        return (Object) (switch (col) {
            case 0 -> investmentList.get(row).getName();
            case 1 -> investmentList.get(row).getPrice();
            case 2 -> investmentList.get(row).getAmount();
            default -> null;
           
        });
    }
    public void setValue(int current, Investment New){
        investmentList.set(current, New);
        fireTableRowsUpdated(0, investmentList.size()-1);
    }
    public void setValueAt(int row, int col){
        
        fireTableCellUpdated(row, col);
    }
    @Override
    public int getColumnCount() {
        return 3;
    }
    @Override
    public boolean isCellEditable(int row, int col){
        return true;
    }
    
    public void addrow(Investment rowdata){
        investmentList.add(rowdata);
        fireTableRowsInserted(investmentList.size(),investmentList.size());
        System.out.print(getRowCount());
    }
    public void fireTableRowsInserted(){
        fireTableRowsInserted(investmentList.size()-1,investmentList.size()-1);
    }
    public void deleteRow(Investment selectedRow, int rowcount){
        investmentList.remove(selectedRow);
        fireTableRowsDeleted(rowcount, rowcount);
    }
    
}