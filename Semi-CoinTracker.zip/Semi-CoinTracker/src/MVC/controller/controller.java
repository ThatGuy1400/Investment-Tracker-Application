/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC.controller;

import MVC.view.EncryptionUI;
import MVC.view.InvestmentListUI;
import MVC.view.ListofKeysUI;
import MVC.view.PasswordUI;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import semi.cointracker.CryptoKey;
import semi.cointracker.KeyList;

/**
 *
 * @author brand
 */
public class controller {
    private KeyList ListofKeys;
    private CryptoKey Key;
    private EncryptionUI encryptionUI;
    private ListofKeysUI listofkeysUI;
    private PasswordUI passwordUI;
    private InvestmentListUI investmentlistUI;
    
 public controller() throws IOException, FileNotFoundException, ClassNotFoundException{
     ListofKeys = new KeyList();
     encryptionUI = new EncryptionUI(this);
     //investmentlistUI.setVisible(false);
     encryptionUI.setVisible(true);
 }   
    
public ArrayList<CryptoKey> getKeyList(){  
    return ListofKeys.getKeyList();
}
public LinkedList<CryptoKey> getLinkedList(){
    return ListofKeys.getLinkedList();
}
public void list() throws IOException, FileNotFoundException, ClassNotFoundException{
    listofkeysUI = new ListofKeysUI(this);
    passwordUI.setVisible(false);
    listofkeysUI.setVisible(true);
}
public void password() {
    passwordUI = new PasswordUI(this);
    encryptionUI.setVisible(false);
    passwordUI.setVisible(true);
}
public void write() throws IOException{
    ListofKeys.writeKeyListFile();
}
public void backtoencryption(){
    listofkeysUI.setVisible(false);
}
public void backtoinvestmentlist(){
    encryptionUI.setVisible(false);
}
    
//public void movetokey(){
  //  investmentlistUI.setVisible(false);
//}
    
}
