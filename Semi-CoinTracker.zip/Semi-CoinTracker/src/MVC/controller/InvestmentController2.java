/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC.controller;

import MVC.view.InvestmentListUI;
import MVC.view.InvestmentsUI;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import semi.cointracker.Investment;
import semi.cointracker.InvestmentList;
import semi.cointracker.InvestmentTableModel;
/**
 *
 * @author brand
 */
public class InvestmentController2  {
    private InvestmentList theinvestmentList;
    private ArrayList<Investment> ArrayList;
    private InvestmentTableModel theInvestmentTableModel;
    private InvestmentListUI investmentListUI;
    private InvestmentsUI investmentsUI;
    private Investment investment;
    private String current;

public InvestmentController2() throws IOException, FileNotFoundException, ClassNotFoundException{
        theinvestmentList = new InvestmentList();
        //investmentsUI = new InvestmentsUI(this);
        theInvestmentTableModel = new InvestmentTableModel(theinvestmentList.getInvestmentList());
        //System.out.print(ArrayList);
     
        investmentListUI = new InvestmentListUI(this);
        investmentListUI.setVisible(true);   
}
public InvestmentTableModel getInvestmentTableModel(){
    return theInvestmentTableModel;
}
public ArrayList<Investment> getInvestmentList() {
return theinvestmentList.getInvestmentList();}

public void getInvestmentDetailUI(int selectedRowModel){
    investmentsUI = new InvestmentsUI(this, selectedRowModel);
    investmentListUI.setVisible(false);
    investmentsUI.setVisible(true);
}

public Object getInvestment(int selectedModelRow){
    return theinvestmentList.getInvestmentList().get(selectedModelRow);
}
public void getclearinvestmentsUI (int selectedRow){
    investmentsUI = new InvestmentsUI(this, selectedRow);
    investmentListUI.setVisible(false);
    investmentsUI.setVisible(true);        
}
public void backtoList(){
    investmentListUI.setVisible(true);
    investmentsUI.setVisible(false);
}

public void movetokey(){
    investmentListUI.setVisible(false);
}
public void write() throws IOException{
    theinvestmentList.writeKeyListFile();
}

}
        