/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC.view;


import MVC.controller.InvestmentController2;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import semi.cointracker.Investment;
import semi.cointracker.InvestmentList;
import semi.cointracker.InvestmentTableModel;


public class InvestmentsUI extends javax.swing.JFrame {
    private InvestmentController2 investmentController2;
    private int currentSelectedRow;
    private Investment investment;
    private Investment currentinvestment;
    private InvestmentTableModel ITM;
    private ArrayList<Investment> ListofInvestments;
    private InvestmentList IL;
    private JTable investmentTable;
    private InvestmentListUI InvestmentList;
    
    
    
public InvestmentsUI(InvestmentController2 newinvestmentController, int selectedModelRow){
    investmentController2 = newinvestmentController;
    //investmentTable.getModel().addTableModelListener(this);
    //IL = new InvestmentList();
    ListofInvestments = investmentController2.getInvestmentList();
    currentSelectedRow = selectedModelRow;
    currentinvestment = (Investment) newinvestmentController.getInvestment(currentSelectedRow);
    initComponents();
    parseInvestment(); 
    System.out.print(selectedModelRow);
}    
 public void parseInvestment(){
        InvestmentName.setText(currentinvestment.getName());
        InvestmentPrice.setText(String.valueOf(currentinvestment.getPrice()));
        InvestmentAmount.setText (String.valueOf(currentinvestment.getAmount()));
        InvestmentTotal.setText(String.valueOf(currentinvestment.Calculation()));
    } 
 public void parseNewInvestment(){
     
 }                 
public void AddInvestment(){
       InvestmentName.getText();
        InvestmentName.setText(InvestmentName.getText());
        double pricce = Double.parseDouble(InvestmentPrice.getText());
       InvestmentPrice.setText(String.valueOf(pricce));
        double amountt = Double.parseDouble(InvestmentAmount.getText());
       InvestmentAmount.setText(String.valueOf(amountt));
        double calc = amountt*pricce;
        InvestmentTotal.setText(String.valueOf(calc));
        investment = new Investment(InvestmentName.getText(), pricce, amountt);
        //ListofInvestments.add(investment);
        investmentController2.getInvestmentTableModel().addrow(investment);
       // investmentController2.getInvestmentTableModel().fireTableRowsInserted(0,ListofInvestments.size()-1 );  
}


public class AddButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Object B = e.getSource();
            if (B == BAdd){     
            AddInvestment();
                try {
                    investmentController2.write();
                } catch (IOException ex) {
                    Logger.getLogger(InvestmentsUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            investmentController2.backtoList();
            
            }
       }
    
}
public class DeleteButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Object B = e.getSource();
            if (B == BDelete){
                investmentController2.getInvestmentTableModel().deleteRow(currentinvestment, currentSelectedRow);
                try {
                    investmentController2.write();
                } catch (IOException ex) {
                    Logger.getLogger(InvestmentsUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                investmentController2.backtoList();
            }
        }
}
public class QuitButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Object B = e.getSource();
            if(B == BQuit){
                System.exit(0);
            }
        }
}
public void Update(){
        InvestmentName.getText();
        InvestmentName.setText(InvestmentName.getText());
        double pricce = Double.parseDouble(InvestmentPrice.getText());
        InvestmentPrice.setText(String.valueOf(pricce));
        double amountt = Double.parseDouble(InvestmentAmount.getText());
        InvestmentAmount.setText(String.valueOf(amountt));
        double calc = amountt*pricce;
        InvestmentTotal.setText(String.valueOf(calc));
        investment = new Investment(InvestmentName.getText(), pricce, amountt);
        ListofInvestments.set(currentSelectedRow, investment);
        investmentController2.getInvestmentTableModel().setValueAt(currentSelectedRow,1 );
        //investmentController2.getInvestmentTableModel().setValue(currentSelectedRow, investment);
}
public void Update2(){
    double pricce = Double.parseDouble(InvestmentPrice.getText());
    InvestmentPrice.setText(String.valueOf(pricce));
    ListofInvestments.set(currentSelectedRow, investment);
        investmentController2.getInvestmentTableModel().setValueAt(pricce, currentSelectedRow, 2);
}
public void Update3(){
    double amountt = Double.parseDouble(InvestmentAmount.getText());
    InvestmentAmount.setText(String.valueOf(amountt));
    ListofInvestments.set(currentSelectedRow, investment);
        investmentController2.getInvestmentTableModel().setValueAt(amountt, currentSelectedRow, 3);
}
public class UpdateButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Update();
            }
            catch(Exception E){
                Update2();
                Update3();
            }
            try {
                    investmentController2.write();
                } catch (IOException ex) {
                    Logger.getLogger(InvestmentsUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            //Update();
            investmentController2.backtoList();
        }
    
}

        
   private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        InvestmentName = new javax.swing.JTextField();
        InvestmentPrice = new javax.swing.JTextField();
        InvestmentAmount = new javax.swing.JTextField();
        InvestmentTotal = new javax.swing.JTextField();
        BAdd = new javax.swing.JButton();
        BAdd.addActionListener(new AddButton());
        BDelete = new javax.swing.JButton();
        BDelete.addActionListener(new DeleteButton());
        BUpdate = new javax.swing.JButton();
        BUpdate.addActionListener(new UpdateButton());
        BQuit = new javax.swing.JButton();
        BQuit.addActionListener(new QuitButton());

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel1.setText("Investment");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel2.setText("Name:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel3.setText("Price:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel4.setText("Amount:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel5.setText("Total:");

        BAdd.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BAdd.setText("Add");

        BDelete.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BDelete.setText("Delete");

        BUpdate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BUpdate.setText("Update");

        BQuit.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BQuit.setText("Quit");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(InvestmentName)
                            .addComponent(InvestmentPrice)
                            .addComponent(InvestmentAmount)
                            .addComponent(InvestmentTotal)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(BAdd)
                        .addGap(30, 30, 30)
                        .addComponent(BDelete)
                        .addGap(18, 18, 18)
                        .addComponent(BUpdate)
                        .addGap(18, 18, 18)
                        .addComponent(BQuit)))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(InvestmentName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(InvestmentPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(InvestmentAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(InvestmentTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BAdd)
                    .addComponent(BDelete)
                    .addComponent(BUpdate)
                    .addComponent(BQuit))
                .addContainerGap(63, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
         this.setSize(500, 400);
         this.setLocationRelativeTo(null);
        pack();
    }// </editor-fold>                          

    /**
     * @param args the command line arguments
     */
    private javax.swing.JButton BAdd;
    private javax.swing.JButton BDelete;
    private javax.swing.JButton BQuit;
    private javax.swing.JButton BUpdate;
    private javax.swing.JTextField InvestmentAmount;
    private javax.swing.JTextField InvestmentName;
    private javax.swing.JTextField InvestmentPrice;
    private javax.swing.JTextField InvestmentTotal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration   

                   
}