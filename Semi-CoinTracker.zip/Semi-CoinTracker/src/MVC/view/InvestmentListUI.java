/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC.view;


import MVC.controller.InvestmentController2;
import MVC.controller.controller;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JScrollPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import semi.cointracker.Investment;
import semi.cointracker.InvestmentTableModel;
/**
 *
 * @author brand
 */
public class InvestmentListUI extends javax.swing.JFrame implements TableModelListener{
    private JPanel tablePanel;
    private JPanel buttonPanel;
    private JTable investmentTable;
    private JButton doneButton;
    private JButton detailsButton;
    private JButton newButton;
    private JButton KeyButton;
    private JScrollPane tableScroller;
    private InvestmentTableModel ITM;
    private InvestmentController2 controller;
    private ArrayList<Investment> Array;
    private controller keycontroller;
    
 

    
public InvestmentListUI(InvestmentController2 investmentController2 ){
    this.controller = investmentController2;
    initComponents(); 
    investmentTable.getModel().addTableModelListener(this);
    //System.out.print(controller.getInvestmentTableModel().getRowCount());
}
public void updatetable(){
    investmentTable.revalidate();
}


    @Override
    public void tableChanged(TableModelEvent e) {
        if (e.getType()==TableModelEvent.INSERT ){
            investmentTable.repaint();
            //controller.getInvestmentTableModel().fireTableRowsInserted();
            //System.out.print("Table changed");    
        }   
    }

  
    
public class DetailsButtonListener implements ActionListener{     

    public void actionPerformed(ActionEvent evt){
        Object B = evt.getSource();
        if (B == detailsButton){
    int selectedTableRow = investmentTable.getSelectedRow();
    int selectedModelRow = investmentTable.convertRowIndexToModel(selectedTableRow);
        if (selectedModelRow < 0)
            selectedModelRow = 0;
        InvestmentListUI.this.controller.getInvestmentDetailUI(selectedModelRow);
        System.out.print(selectedModelRow);
    }
}
    }
public class DoneButton implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            Object B = e.getSource();
             if (B == doneButton){
            System.exit(0);
            System.out.print("closed");
        }
        } 
}
public class NewButton implements ActionListener{

            @Override
            public void actionPerformed(ActionEvent e) {
                 Object B = e.getSource();
                 if (B == newButton){
                      int selectedTableRow = investmentTable.getSelectedRow();
    int selectedModelRow = investmentTable.convertRowIndexToModel(selectedTableRow);
        if (selectedModelRow < 0)
            selectedModelRow = 0;
                     InvestmentListUI.this.controller.getclearinvestmentsUI(selectedModelRow);
                 }
            }
    
}
public class KeyButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                keycontroller = new controller();
                controller.movetokey();
            } catch (IOException ex) {
                Logger.getLogger(InvestmentListUI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(InvestmentListUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    
}


  
        



    
    public void initComponents(){
    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    tablePanel = new JPanel();
    buttonPanel = new JPanel(new GridLayout(1,4));
    investmentTable = new JTable(controller.getInvestmentTableModel());
    investmentTable.getColumnModel(). getColumn(0).setPreferredWidth(25);
    investmentTable.getColumnModel(). getColumn(1).setPreferredWidth(50);
    doneButton = new JButton("Done");
    doneButton.addActionListener(new DoneButton());
    detailsButton = new JButton("Show Details");
    detailsButton.addActionListener(new DetailsButtonListener());
    //newButton = new JButton("New");
   // newButton.addActionListener(new NewButton());
    KeyButton = new JButton("Keys");
    KeyButton.addActionListener(new KeyButton());
    buttonPanel.add(KeyButton);
    //buttonPanel.add(newButton);
    buttonPanel.add(detailsButton);
    buttonPanel.add(doneButton);
    tableScroller = new JScrollPane(investmentTable);
    investmentTable.setFillsViewportHeight(true);
    tableScroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    tableScroller.setPreferredSize(new Dimension(350,300));
    tablePanel.add(tableScroller);
    this.setSize(500, 400);
    this.setLocationRelativeTo(null);
    this.setContentPane(new JPanel(new BorderLayout()));
    this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    this.getContentPane().add(tablePanel, BorderLayout.CENTER);
    }  
}
