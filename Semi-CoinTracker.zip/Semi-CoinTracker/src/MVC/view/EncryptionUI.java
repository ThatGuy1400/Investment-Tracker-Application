/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC.view;

import MVC.controller.InvestmentController2;
import MVC.controller.controller;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import semi.cointracker.CryptoKey;
import semi.cointracker.KeyList;
import semi.cointracker.keyComparator;

/**
 *
 * @author brand
 */
public class EncryptionUI extends javax.swing.JFrame implements Serializable{
    private CryptoKey cryptokey;
    private ArrayList<CryptoKey> ListofKeys;
    private KeyList keylist;
    private static final String UNICODE_FORMAT = "UTF-8";
    private controller Controller;
    private ListofKeysUI listofkeysUI;
    private LinkedList<CryptoKey> LL = new LinkedList<>();

    
public EncryptionUI(controller controller)  {
        this.Controller = controller;
        initComponents();
        ListofKeys = controller.getKeyList();
        LL = controller.getLinkedList();
    }
 

public void newparse(CryptoKey cryptokey) {
    Name.getText();
    Key.getText();
    Name.setText(Name.getText());
    Key.setText(Key.getText());
    cryptokey = new CryptoKey(Name.getText(), Key.getText());
    ListofKeys.add(cryptokey);
    ListofKeys.sort(new keyComparator());
}
public static SecretKey generateKey(String encryptionType) throws NoSuchAlgorithmException{
    try{
        KeyGenerator keyGenerator = KeyGenerator.getInstance(encryptionType);
        SecretKey mykey = keyGenerator.generateKey();
        return mykey;
    }
    catch(Exception E){
        return null;
    }
 
}    
public String SKey(){
    String text = Key.getText();
       try{
        SecretKey key = generateKey("AES");
        Cipher cipher;
        cipher = Cipher.getInstance("AES");
        
        byte[] encryptedData = encryptString(text, key,cipher );
        String encryptedString = new String(encryptedData);
        String decrypted = decryptString(encryptedData, key, cipher);
        return encryptedString + ", " + decrypted;
    }
    catch(Exception E){
        return null; 
    }
}

public static byte[] encryptString(String datatoEncrypt, SecretKey mykey, Cipher cipher){
    try{
        byte[] text = datatoEncrypt.getBytes(UNICODE_FORMAT);
        cipher.init(Cipher.ENCRYPT_MODE, mykey);
        byte[] textEncrypted = cipher.doFinal(text);
        return textEncrypted;
    }
    catch(Exception E){
        return null;
    }
}
public static String decryptString(byte[] dataToDecrypt, SecretKey myKey, Cipher cipher){
    try{
        cipher.init(Cipher.DECRYPT_MODE, myKey);
        byte[] textDecrypted = cipher.doFinal(dataToDecrypt);
        String result = new String (textDecrypted);
        return result;
    }
    catch(Exception E){
        return null;
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        EncryptionButton = new javax.swing.JButton();
        Key = new javax.swing.JTextField();
        Name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        SeeKeys = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel1.setText("Wallet Crypto Key ");

        EncryptionButton.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        EncryptionButton.setText("Save");
        EncryptionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EncryptionButtonActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel2.setText("Name:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel3.setText("Key:");

        SeeKeys.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        SeeKeys.setText("See Keys");
        SeeKeys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SeeKeysActionPerformed(evt);
            }
        });

        BackButton.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 70, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(119, 119, 119))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Key, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(EncryptionButton, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SeeKeys, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BackButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Key, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(87, 87, 87)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EncryptionButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SeeKeys, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void EncryptionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EncryptionButtonActionPerformed
          newparse(cryptokey);
          SKey();
          System.out.print(SKey());
        
         // System.out.print(SKey());
    }//GEN-LAST:event_EncryptionButtonActionPerformed

    private void SeeKeysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SeeKeysActionPerformed

            Controller.password();
        try {
            Controller.write();
        } catch (IOException ex) {
            Logger.getLogger(EncryptionUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_SeeKeysActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        try {
            InvestmentController2 con2 = new InvestmentController2();
        } catch (IOException ex) {
            Logger.getLogger(EncryptionUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(EncryptionUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        Controller.backtoinvestmentlist();
    }//GEN-LAST:event_BackButtonActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JButton EncryptionButton;
    private javax.swing.JTextField Key;
    private javax.swing.JTextField Name;
    private javax.swing.JButton SeeKeys;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
